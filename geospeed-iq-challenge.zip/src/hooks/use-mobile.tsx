import * as React from "react";

const MOBILE_BREAKPOINT = 768;
const MOBILE_LANDSCAPE_MAX_HEIGHT = 520;
const TOUCH_TABLET_MAX_WIDTH = 1024;
const COMPACT_GAME_MAX_WIDTH = 1180;
const COMPACT_GAME_MAX_HEIGHT = 760;
const DUAL_PANEL_GAME_MIN_WIDTH = 820;
const DUAL_PANEL_GAME_MIN_HEIGHT = 400;
const DUAL_PANEL_TOUCH_LANDSCAPE_MIN_HEIGHT = 360;

function detectMobileViewport() {
  if (typeof window === "undefined") return false;

  const isNarrowViewport = window.innerWidth < MOBILE_BREAKPOINT;
  const isTouchDevice = window.matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0;
  const isCompactLandscape = isTouchDevice && window.innerHeight <= MOBILE_LANDSCAPE_MAX_HEIGHT;
  const isTouchTabletViewport = isTouchDevice && window.innerWidth <= TOUCH_TABLET_MAX_WIDTH;

  return isNarrowViewport || isCompactLandscape || isTouchTabletViewport;
}

function detectCompactGameViewport() {
  if (typeof window === "undefined") return false;

  return window.innerWidth < COMPACT_GAME_MAX_WIDTH || window.innerHeight < COMPACT_GAME_MAX_HEIGHT;
}

function detectDualPanelGameViewport() {
  if (typeof window === "undefined") return false;

  const isLandscape = window.innerWidth > window.innerHeight;
  const isTouchDevice = window.matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0;
  const minHeight = isTouchDevice ? DUAL_PANEL_TOUCH_LANDSCAPE_MIN_HEIGHT : DUAL_PANEL_GAME_MIN_HEIGHT;

  return isLandscape && window.innerWidth >= DUAL_PANEL_GAME_MIN_WIDTH && window.innerHeight >= minHeight;
}

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const widthQuery = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const landscapeQuery = window.matchMedia(`(max-height: ${MOBILE_LANDSCAPE_MAX_HEIGHT}px) and (pointer: coarse)`);
    const touchTabletQuery = window.matchMedia(`(max-width: ${TOUCH_TABLET_MAX_WIDTH}px) and (pointer: coarse)`);

    const onChange = () => {
      setIsMobile(detectMobileViewport());
    };

    widthQuery.addEventListener("change", onChange);
    landscapeQuery.addEventListener("change", onChange);
    touchTabletQuery.addEventListener("change", onChange);
    window.addEventListener("resize", onChange);
    window.addEventListener("orientationchange", onChange);

    setIsMobile(detectMobileViewport());

    return () => {
      widthQuery.removeEventListener("change", onChange);
      landscapeQuery.removeEventListener("change", onChange);
      touchTabletQuery.removeEventListener("change", onChange);
      window.removeEventListener("resize", onChange);
      window.removeEventListener("orientationchange", onChange);
    };
  }, []);

  return !!isMobile;
}

export function useIsLandscapeViewport() {
  const [isLandscape, setIsLandscape] = React.useState(false);

  React.useEffect(() => {
    if (typeof window === "undefined") return;

    const onChange = () => {
      setIsLandscape(window.innerWidth > window.innerHeight);
    };

    onChange();
    window.addEventListener("resize", onChange);
    window.addEventListener("orientationchange", onChange);

    return () => {
      window.removeEventListener("resize", onChange);
      window.removeEventListener("orientationchange", onChange);
    };
  }, []);

  return isLandscape;
}

export function useIsCompactGameViewport() {
  const [isCompactGameViewport, setIsCompactGameViewport] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const widthQuery = window.matchMedia(`(max-width: ${COMPACT_GAME_MAX_WIDTH - 1}px)`);
    const heightQuery = window.matchMedia(`(max-height: ${COMPACT_GAME_MAX_HEIGHT - 1}px)`);

    const onChange = () => {
      setIsCompactGameViewport(detectCompactGameViewport());
    };

    widthQuery.addEventListener("change", onChange);
    heightQuery.addEventListener("change", onChange);
    window.addEventListener("resize", onChange);
    window.addEventListener("orientationchange", onChange);

    setIsCompactGameViewport(detectCompactGameViewport());

    return () => {
      widthQuery.removeEventListener("change", onChange);
      heightQuery.removeEventListener("change", onChange);
      window.removeEventListener("resize", onChange);
      window.removeEventListener("orientationchange", onChange);
    };
  }, []);

  return !!isCompactGameViewport;
}

export function useHasDualPanelGameViewport() {
  const [hasDualPanelGameViewport, setHasDualPanelGameViewport] = React.useState<boolean | undefined>(undefined);

  React.useEffect(() => {
    const widthQuery = window.matchMedia(`(min-width: ${DUAL_PANEL_GAME_MIN_WIDTH}px)`);
    const heightQuery = window.matchMedia(`(min-height: ${DUAL_PANEL_GAME_MIN_HEIGHT}px)`);
    const touchLandscapeHeightQuery = window.matchMedia(`(min-height: ${DUAL_PANEL_TOUCH_LANDSCAPE_MIN_HEIGHT}px) and (pointer: coarse)`);
    const orientationQuery = window.matchMedia("(orientation: landscape)");

    const onChange = () => {
      setHasDualPanelGameViewport(detectDualPanelGameViewport());
    };

    widthQuery.addEventListener("change", onChange);
    heightQuery.addEventListener("change", onChange);
    touchLandscapeHeightQuery.addEventListener("change", onChange);
    orientationQuery.addEventListener("change", onChange);
    window.addEventListener("resize", onChange);
    window.addEventListener("orientationchange", onChange);

    setHasDualPanelGameViewport(detectDualPanelGameViewport());

    return () => {
      widthQuery.removeEventListener("change", onChange);
      heightQuery.removeEventListener("change", onChange);
      touchLandscapeHeightQuery.removeEventListener("change", onChange);
      orientationQuery.removeEventListener("change", onChange);
      window.removeEventListener("resize", onChange);
      window.removeEventListener("orientationchange", onChange);
    };
  }, []);

  return !!hasDualPanelGameViewport;
}
